import hashlib
import secrets
import configparser
import os
from datetime import datetime

class PasswordManager:
    def __init__(self, auth_file='auth_secrets.ini'):
        self.auth_file = auth_file
        self.ensure_auth_file()
    
    def ensure_auth_file(self):
        """Crea il file auth se non esiste"""
        if not os.path.exists(self.auth_file):
            config = configparser.ConfigParser()
            config['auth'] = {
                'username': '',
                'password_hash': '',
                'password_salt': '',
                'created_at': datetime.now().isoformat(),
                'last_modified': datetime.now().isoformat()
            }
            self._save_config(config)
    
    def generate_password_hash(self, password):
        """Genera hash sicuro della password con salt"""
        salt = secrets.token_hex(32)  # Salt di 32 byte
        password_hash = hashlib.sha256((password + salt).encode()).hexdigest()
        return password_hash, salt
    
    def verify_password(self, password, username):
        """Verifica se la password è corretta"""
        config = self._load_config()
        
        if config.get('auth', 'username') != username:
            return False
        
        stored_hash = config.get('auth', 'password_hash')
        salt = config.get('auth', 'password_salt')
        
        # Se il file è vuoto (prima configurazione)
        if not stored_hash or not salt:
            return False
        
        test_hash = hashlib.sha256((password + salt).encode()).hexdigest()
        return test_hash == stored_hash
    
    def set_credentials(self, username, password):
        """Imposta nuove credenziali"""
        password_hash, salt = self.generate_password_hash(password)
        
        config = self._load_config()
        
        # ✅ CORRETTO: usa get() con fallback
        created_at = config.get('auth', 'created_at', fallback=datetime.now().isoformat())
        
        config['auth'] = {
            'username': username,
            'password_hash': password_hash,
            'password_salt': salt,
            'created_at': created_at,
            'last_modified': datetime.now().isoformat()
        }
        
        self._save_config(config)
        return True
    
    def get_username(self):
        """Restituisce solo l'username (sicuro)"""
        config = self._load_config()
        return config.get('auth', 'username', fallback='')
    
    def is_configured(self):
        """Verifica se il server è già configurato"""
        config = self._load_config()
        username = config.get('auth', 'username', fallback='')
        password_hash = config.get('auth', 'password_hash', fallback='')
        return bool(username and password_hash)
    
    def _load_config(self):
        """Carica configurazione auth"""
        config = configparser.ConfigParser()
        config.read(self.auth_file)
        return config
    
    def _save_config(self, config):
        """Salva configurazione auth"""
        with open(self.auth_file, 'w') as configfile:
            config.write(configfile)

# Istanza globale
password_manager = PasswordManager()
