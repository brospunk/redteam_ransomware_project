#!/usr/bin/env python3
"""
Script di setup iniziale per il server Red Team
ESEGUIRE SOLO UNA VOLTA!
"""

import getpass
import sys
import os
from password_manager import PasswordManager

def setup_server():
    print("🔧 RED TEAM DASHBOARD - SETUP INIZIALE")
    print("=" * 50)
    print("⚠️  ESEGUIRE QUESTO SCRIPT SOLO UNA VOLTA")
    print()
    
    pm = PasswordManager()
    
    # Verifica se già configurato
    if pm.is_configured():
        print("❌ Server già configurato!")
        print(f"🔑 Username attuale: {pm.get_username()}")
        print("💡 Per reimpostare, elimina il file 'auth_secrets.ini'")
        return
    
    # Configurazione username
    username = input("Username admin [redteam]: ").strip()
    if not username:
        username = "redteam"
    
    # Configurazione password
    while True:
        password = getpass.getpass("Password admin: ")
        confirm = getpass.getpass("Conferma password: ")
        
        if password != confirm:
            print("❌ Le password non coincidono! Riprova.")
            continue
        
        if len(password) < 8:
            print("❌ La password deve essere di almeno 8 caratteri!")
            continue
        
        # Password valida
        break
    
    # Salva credenziali
    success = pm.set_credentials(username, password)
    
    if success:
        print()
        print("✅ SETUP COMPLETATO!")
        print("📁 File creato: auth_secrets.ini")
        print("🔐 Credenziali salvate in modo sicuro (hashate)")
        print()
        print(f"🔑 Username: {username}")
        print("🔒 Password: [hashata e sicura]")
        print()
        print("🚀 Avvia il server con: python dashboard.py")
        print("📍 Accedi a: http://localhost:8573")
        print()
        print("⚠️  IMPORTANTE:")
        print("   - Aggiungi 'auth_secrets.ini' al .gitignore")
        print("   - Backup sicuro del file auth_secrets.ini")
        print("   - Non condividere mai il file auth_secrets.ini")
    else:
        print("❌ Errore durante il setup!")

if __name__ == "__main__":
    try:
        setup_server()
    except KeyboardInterrupt:
        print("\n❌ Setup cancellato")
        sys.exit(1)
